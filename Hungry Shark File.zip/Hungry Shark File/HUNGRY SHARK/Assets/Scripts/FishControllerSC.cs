using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishControllerSC : MonoBehaviour
{
    const float MOVING_SPEED=-0.02f;
    void start()
    {
        gameObject.tag="Wrong Fish";
    }
    void Update()
    {
        move();
    }
    void move()
    {
        transform.position = new Vector3(transform.position.x+MOVING_SPEED , transform.position.y , transform.position.z);
        if(transform.position.x<-9)
        {
            Destroy(gameObject);
        }
    }
}
