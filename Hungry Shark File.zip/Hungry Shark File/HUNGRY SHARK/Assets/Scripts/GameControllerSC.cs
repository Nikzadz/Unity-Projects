using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameControllerSC : MonoBehaviour
{
    public SharkController sharkController;
    public FishSpawnerSC fishSpawnerSC;
    public Text scoretxt;
    public Text timetxt;
    public GameObject tryAgain;
    string score="";
    public float timeRemaining = 300f;
    int getScore()
    {
        return sharkController.score;
    }
    void setScore()
    {
        score=getScore().ToString();
        scoretxt.text="Score: "+score;
    }
    void Update()
    {
        setScore();
        checkTime();
    }
    void checkTime()
    {
        if (timeRemaining > 0)
        {
            timeRemaining -= Time.deltaTime;
            string minutes = Mathf.Floor(timeRemaining / 60).ToString("00");
            string seconds = (timeRemaining % 60).ToString("00");
            timetxt.text="Time Remaining: "+minutes + " : " + seconds;
        }

        else{
            timetxt.text="Time is over!";
            gameOver();
        }
    }
    void gameOver()
    {
        fishSpawnerSC.gameover=true;
        tryAgain.SetActive(true);
    }
    public void startAgain()
    {
        SceneManager.LoadScene (sceneName:"Gameplay");
    }

}
