using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishSpawnerSC : MonoBehaviour
{
   public GameObject[] fish;
    public bool gameover=false ;
    public int countofspawn=0;
    void Start()
    {
        InvokeRepeating("spawn", 2, 4);
    }
    void Update()
    {

    }
    public void spawn()
    {
        if (gameover == false)
        {
            float randpos = Random.Range(-4f, 3.6f);
            int randindex = (int)Random.Range(0, fish.Length);
            Vector3 spawnpos = new Vector3(8.5f, randpos, -1);
            Instantiate(fish[randindex], spawnpos, Quaternion.identity);
            countofspawn += 1;
        }

    }
}
