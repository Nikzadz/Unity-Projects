using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuManagerSC : MonoBehaviour
{
    //Changes the menu scene to gameplay scene 
    public void goToGamePlay()
    {
        SceneManager.LoadScene (sceneName:"Gameplay");
    }
}
