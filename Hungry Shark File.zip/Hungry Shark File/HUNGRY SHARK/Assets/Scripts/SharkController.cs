using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SharkController : MonoBehaviour
{
    public int correctFishCount=0;
    public int wrongFishCount=0;
    public int score=0;
    const float MOVING_SPEED=0.02f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transformChange();
    }

    void transformChange()
    {
        if (Input.GetKey(KeyCode.UpArrow)||Input.GetKey(KeyCode.W))
        {
            transform.position = new Vector3(transform.position.x, Mathf.Clamp(transform.position.y+MOVING_SPEED, -4f, 3.6f), transform.position.z);
        }

        if (Input.GetKey(KeyCode.DownArrow)||Input.GetKey(KeyCode.S))
        {
            transform.position = new Vector3(transform.position.x, Mathf.Clamp(transform.position.y-MOVING_SPEED, -4f, 3.6f), transform.position.z);
        }
        if (Input.GetKey(KeyCode.LeftArrow)||Input.GetKey(KeyCode.A))
        {
            transform.position = new Vector3(Mathf.Clamp(transform.position.x-MOVING_SPEED, -4.75f, -1.75f),transform.position.y , transform.position.z);
        }

        if (Input.GetKey(KeyCode.RightArrow)||Input.GetKey(KeyCode.D))
        {
            transform.position = new Vector3(Mathf.Clamp(transform.position.x+MOVING_SPEED, -4.75f, -1.75f),transform.position.y , transform.position.z);
        }
    }
    void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.name=="WrongFish(Clone)")
        {
            wrongFishCount++;
            score--;
        }
        else if(collision.gameObject.name=="CorrectFish(Clone)")
        {
            correctFishCount++;
            score++;
        }
        Destroy(collision.gameObject);
    }
    
}
